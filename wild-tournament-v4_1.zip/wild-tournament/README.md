# 🔥 The Wild Tournament v4 — Railway Edition

<div align="center">

![Free Fire](https://img.shields.io/badge/Game-Free%20Fire-orange?style=for-the-badge)
![Node.js](https://img.shields.io/badge/Backend-Node.js-green?style=for-the-badge&logo=node.js)
![SQLite](https://img.shields.io/badge/Storage-SQLite-blue?style=for-the-badge)
![Railway](https://img.shields.io/badge/Host-Railway.app-purple?style=for-the-badge)

**Free Fire Cash Tournament Platform with Player Authentication**

</div>

---

## ✨ What's New in v4

- **Player Accounts** — Players can register/login with username + password (JWT-based)
- **My Dashboard** — Players see all their registrations, earnings, room IDs, and stats
- **Auto-fill Registration** — Logged-in players have UID/IGN/WhatsApp pre-filled
- **Admin Users Page** — View all registered player accounts
- **Railway-ready** — `railway.toml` included for instant deployment

---

## 📁 Project Structure

```
wild-tournament/
├── backend/
│   └── server.js           ← API server (Node.js + Express + SQLite)
├── public/
│   ├── index.html          ← Player tournament site
│   ├── admin.html          ← Admin panel
│   ├── login.html          ← Player login / register page
│   ├── dashboard.html      ← Player personal dashboard
│   └── images/
│       └── qr-payment.jpg  ← UPI QR code
├── .env.example            ← Config template (copy to .env)
├── .gitignore
├── railway.toml            ← Railway deployment config
├── package.json
└── README.md
```

---

## 🔐 Authentication Flow

### Player (JWT)
1. Player visits `/login` → registers or logs in → gets JWT token stored in `localStorage`
2. Token sent as `Authorization: Bearer <token>` header on all player API calls
3. `/dashboard` shows their registration history, room IDs (when payment verified), and stats
4. Registration form auto-fills their UID/IGN/WhatsApp if logged in

### Admin (Password)
- Unchanged — send header `x-admin-password: YOUR_PASSWORD` (or query `?password=`)
- Admin panel at `/admin`

---

## 🚀 Deploy on Railway (Step by Step)

### Step 1: Push to GitHub

```cmd
cd wild-tournament
git init
git add .
git commit -m "Wild Tournament v4"
git remote add origin https://github.com/YOUR-USERNAME/wild-tournament.git
git branch -M main
git push -u origin main
```

### Step 2: Create Railway Project

1. Go to **https://railway.app** → Sign up with GitHub
2. Click **New Project** → **Deploy from GitHub repo**
3. Select your `wild-tournament` repo → Click **Deploy Now**

### Step 3: Add Environment Variables

In Railway dashboard → Your service → **Variables** tab, add:

| Variable | Value |
|----------|-------|
| `NODE_ENV` | `production` |
| `ADMIN_PASSWORD` | `YourStrongPassword123` |
| `JWT_SECRET` | `some_long_random_secret_abc_xyz_789` |
| `UPI_ID` | `tripathi3966@fam` |
| `WHATSAPP_NUMBER` | `+919696187223` |
| `BRONZE_ENTRY` | `5` |
| `SILVER_ENTRY` | `20` |
| `GOLD_ENTRY` | `30` |
| `SQUAD_ENTRY` | `100` |
| `BRONZE_KILL_RATE` | `3` |
| `SILVER_KILL_RATE` | `10` |
| `GOLD_KILL_RATE` | `15` |
| `GOLD_WIN_BONUS` | `60` |
| `SQUAD_WIN_PRIZE` | `180` |
| `BRONZE_MAX_SLOTS` | `48` |
| `SILVER_MAX_SLOTS` | `48` |
| `GOLD_MAX_SLOTS` | `48` |
| `SQUAD_MAX_SLOTS` | `12` |
| `RATE_LIMIT_MAX` | `15` |
| `DB_PATH` | `./backend/tournament.db` |

> ⚠️ **Make JWT_SECRET a long random string** — never share it! It signs player tokens.

### Step 4: Add Persistent Volume (IMPORTANT for SQLite!)

Railway's free tier resets the filesystem on redeploy. To keep your database:

1. Railway Dashboard → Your service → **Volumes** tab
2. Click **Add Volume**
3. Set mount path: `/app/backend`
4. This keeps `tournament.db` safe across deploys

### Step 5: Get Your URL

Railway gives you a URL like `https://wild-tournament-production.up.railway.app`

Test it:
- Site: `https://your-url.railway.app`
- Admin: `https://your-url.railway.app/admin`
- Login: `https://your-url.railway.app/login`
- Dashboard: `https://your-url.railway.app/dashboard`
- Health: `https://your-url.railway.app/api/health`

---

## 🔗 All API Endpoints

### Public Endpoints
| Endpoint | Method | What it does |
|----------|--------|-------------|
| `/ping` | GET | Health keep-alive |
| `/api/health` | GET | Server status |
| `/api/config` | GET | Fees + slot counts |
| `/api/register` | POST | Register for a lobby |
| `/api/status/:ref` | GET | Check registration by REF code |
| `/api/leaderboard` | GET | Top 50 players |

### Player Auth Endpoints (JWT)
| Endpoint | Method | Auth | What it does |
|----------|--------|------|-------------|
| `/api/auth/register` | POST | None | Create player account |
| `/api/auth/login` | POST | None | Login → get JWT token |
| `/api/auth/me` | GET | ✅ JWT | Get profile + history + stats |
| `/api/auth/profile` | PATCH | ✅ JWT | Update profile / change password |
| `/api/auth/my-registrations` | GET | ✅ JWT | Get own registrations |

### Admin Endpoints (Password Header)
| Endpoint | Method | What it does |
|----------|--------|-------------|
| `/api/admin/stats` | GET | Dashboard stats |
| `/api/admin/registrations` | GET | All registrations (filterable) |
| `/api/admin/registration/:id` | PATCH | Verify payment / add results |
| `/api/admin/registration/:id` | DELETE | Delete registration |
| `/api/admin/broadcast-room` | POST | Send room ID to verified players |
| `/api/admin/transactions` | GET | Payment ledger |
| `/api/admin/leaderboard` | GET | Full leaderboard |
| `/api/admin/users` | GET | All player accounts |
| `/api/admin/export` | GET | Download CSV |
| `/api/admin/settings` | PATCH | Update fees/config |

---

## 🏃 Run Locally

```cmd
# Install
npm install

# Create .env from template
cp .env.example .env
# Edit .env with your values

# Start dev server
npm run dev

# Or start production
npm start
```

Visit `http://localhost:3000`

---

## ❓ Troubleshooting

| Problem | Fix |
|---------|-----|
| DB resets on redeploy | Add a Railway Volume mounted at `/app/backend` |
| JWT login fails | Make sure `JWT_SECRET` env var is set on Railway |
| Can't login with new password | Passwords are hashed — old `.env` default won't match DB |
| Admin panel 401 | Check `ADMIN_PASSWORD` in Railway variables |

---

## 📞 Contact

| | |
|--|--|
| 📧 Email | arrogant3966@gmail.com |
| 📱 WhatsApp | [+91 9696187223](https://wa.me/919696187223) |
| 💳 UPI | tripathi3966@fam |

---

<div align="center">© 2025 The Wild Tournament 🔥</div>
