// ══════════════════════════════════════════════════════════
//  THE WILD TOURNAMENT — SERVER v4 (Railway Edition)
//  Stack   : Node.js + Express + SQLite (better-sqlite3)
//  Auth    : Player accounts with JWT + bcrypt
//            Admin: header-based password (unchanged)
//  Host    : Railway.app
// ══════════════════════════════════════════════════════════

require('dotenv').config();

const express   = require('express');
const cors      = require('cors');
const Database  = require('better-sqlite3');
const path      = require('path');
const crypto    = require('crypto');
const rateLimit = require('express-rate-limit');
const fs        = require('fs');
const bcrypt    = require('bcryptjs');
const jwt       = require('jsonwebtoken');

const app  = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'wild-tournament-dev-secret-change-in-production';

// ── MIDDLEWARE ──────────────────────────────────────────────
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ── RATE LIMITING ──────────────────────────────────────────
const regLimit = rateLimit({
  windowMs        : 60 * 60 * 1000,
  max             : parseInt(process.env.RATE_LIMIT_MAX) || 15,
  message         : { success: false, message: 'Too many attempts. Try again in 1 hour.' },
  standardHeaders : true,
  legacyHeaders   : false,
});

const authLimit = rateLimit({
  windowMs        : 15 * 60 * 1000,  // 15 minutes
  max             : 10,
  message         : { success: false, message: 'Too many login attempts. Try again in 15 minutes.' },
  standardHeaders : true,
  legacyHeaders   : false,
});

// ── DATABASE ────────────────────────────────────────────────
const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.cwd(), process.env.DB_PATH)
  : path.join(__dirname, 'tournament.db');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── SCHEMA ──────────────────────────────────────────────────
db.exec(`
  -- Player accounts (for user auth)
  CREATE TABLE IF NOT EXISTS users (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    username     TEXT UNIQUE NOT NULL,
    email        TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    whatsapp     TEXT DEFAULT '',
    ff_uid       TEXT DEFAULT '',
    ff_ign       TEXT DEFAULT '',
    role         TEXT DEFAULT 'player',
    created_at   TEXT DEFAULT (datetime('now','localtime')),
    last_login   TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS registrations (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER DEFAULT NULL,
    ref_code            TEXT UNIQUE NOT NULL,
    uid                 TEXT NOT NULL,
    ign                 TEXT NOT NULL,
    whatsapp            TEXT NOT NULL,
    lobby_id            TEXT NOT NULL,
    lobby_name          TEXT NOT NULL,
    entry_fee           INTEGER NOT NULL DEFAULT 0,
    squad_type          TEXT DEFAULT 'solo',
    squad_members       TEXT DEFAULT '[]',
    payment_upi         TEXT DEFAULT '',
    payment_status      TEXT DEFAULT 'pending',
    payment_verified_at TEXT DEFAULT '',
    room_id             TEXT DEFAULT '',
    room_password       TEXT DEFAULT '',
    room_sent_at        TEXT DEFAULT '',
    kills               INTEGER DEFAULT 0,
    placement           INTEGER DEFAULT 0,
    kill_earnings       INTEGER DEFAULT 0,
    placement_bonus     INTEGER DEFAULT 0,
    total_earnings      INTEGER DEFAULT 0,
    result_status       TEXT DEFAULT 'pending',
    match_date          TEXT DEFAULT (date('now','localtime')),
    created_at          TEXT DEFAULT (datetime('now','localtime')),
    updated_at          TEXT DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ref_code   TEXT NOT NULL,
    uid        TEXT NOT NULL,
    ign        TEXT NOT NULL,
    amount     INTEGER NOT NULL,
    type       TEXT NOT NULL,
    status     TEXT DEFAULT 'pending',
    upi_id     TEXT DEFAULT '',
    notes      TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS leaderboard (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    uid            TEXT UNIQUE NOT NULL,
    ign            TEXT NOT NULL,
    whatsapp       TEXT DEFAULT '',
    total_matches  INTEGER DEFAULT 0,
    total_kills    INTEGER DEFAULT 0,
    total_wins     INTEGER DEFAULT 0,
    total_earnings INTEGER DEFAULT 0,
    total_spent    INTEGER DEFAULT 0,
    last_match_at  TEXT DEFAULT '',
    created_at     TEXT DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT DEFAULT (datetime('now','localtime'))
  );

  CREATE INDEX IF NOT EXISTS idx_reg_lobby    ON registrations(lobby_id);
  CREATE INDEX IF NOT EXISTS idx_reg_status   ON registrations(payment_status);
  CREATE INDEX IF NOT EXISTS idx_reg_date     ON registrations(match_date);
  CREATE INDEX IF NOT EXISTS idx_reg_uid      ON registrations(uid);
  CREATE INDEX IF NOT EXISTS idx_reg_user_id  ON registrations(user_id);
  CREATE INDEX IF NOT EXISTS idx_lb_earnings  ON leaderboard(total_earnings DESC);
  CREATE INDEX IF NOT EXISTS idx_users_uname  ON users(username);
`);

// ── SEED DEFAULT SETTINGS ───────────────────────────────────
const DEFAULTS = {
  bronze_entry    : process.env.BRONZE_ENTRY      || '5',
  silver_entry    : process.env.SILVER_ENTRY      || '20',
  gold_entry      : process.env.GOLD_ENTRY        || '30',
  squad_entry     : process.env.SQUAD_ENTRY       || '100',
  bronze_kill     : process.env.BRONZE_KILL_RATE  || '3',
  silver_kill     : process.env.SILVER_KILL_RATE  || '10',
  gold_kill       : process.env.GOLD_KILL_RATE    || '15',
  gold_win_bonus  : process.env.GOLD_WIN_BONUS    || '60',
  squad_win_prize : process.env.SQUAD_WIN_PRIZE   || '180',
  bronze_slots    : process.env.BRONZE_MAX_SLOTS  || '48',
  silver_slots    : process.env.SILVER_MAX_SLOTS  || '48',
  gold_slots      : process.env.GOLD_MAX_SLOTS    || '48',
  squad_slots     : process.env.SQUAD_MAX_SLOTS   || '12',
  upi_id          : process.env.UPI_ID            || 'tripathi3966@fam',
  whatsapp        : process.env.WHATSAPP_NUMBER   || '+919696187223',
  admin_password  : process.env.ADMIN_PASSWORD    || 'wildadmin2025',
  site_active     : 'true',
};

const seedStmt = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
db.transaction(() => { for (const [k, v] of Object.entries(DEFAULTS)) seedStmt.run(k, v); })();

console.log(`✅  DB ready  → ${DB_PATH}`);

// ── HELPERS ─────────────────────────────────────────────────
function getSetting(key) {
  const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return r ? r.value : (DEFAULTS[key] || '');
}

function getSlotsFilled(lobbyId) {
  return db.prepare(
    `SELECT COUNT(*) c FROM registrations
     WHERE lobby_id = ? AND payment_status != 'rejected'
     AND date(created_at, 'localtime') = date('now', 'localtime')`
  ).get(lobbyId).c;
}

function genRef() {
  return `WLD-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
}

// ── AUTH MIDDLEWARE ──────────────────────────────────────────

// Admin auth (unchanged — header-based password)
function adminAuth(req, res, next) {
  const pass = req.headers['x-admin-password'] || req.query.password;
  if (!pass || pass !== getSetting('admin_password'))
    return res.status(401).json({ success: false, message: 'Unauthorized — wrong admin password.' });
  next();
}

// Player JWT auth — optional: sets req.user if token present
function optionalPlayerAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) return next();
  const token = authHeader.slice(7);
  try {
    req.user = jwt.verify(token, JWT_SECRET);
  } catch (_) { /* invalid token — ignore, treat as guest */ }
  next();
}

// Player JWT auth — required: 401 if not logged in
function requirePlayerAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer '))
    return res.status(401).json({ success: false, message: 'Login required.' });
  const token = authHeader.slice(7);
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (_) {
    return res.status(401).json({ success: false, message: 'Session expired. Please log in again.' });
  }
}

// ══════════════════════════════════════════════════════════
//  KEEP-ALIVE / HEALTH
// ══════════════════════════════════════════════════════════
app.get('/ping', (_req, res) => res.status(200).send('pong 🏓'));

app.get('/api/health', (_req, res) => {
  res.json({
    status : 'ok',
    uptime : Math.floor(process.uptime()) + 's',
    db     : DB_PATH,
    time   : new Date().toISOString(),
    env    : process.env.NODE_ENV || 'development',
  });
});

// ══════════════════════════════════════════════════════════
//  USER AUTH ENDPOINTS
// ══════════════════════════════════════════════════════════

// POST /api/auth/register — create player account
app.post('/api/auth/register', authLimit, async (req, res) => {
  try {
    const { username, password, whatsapp, ff_uid, ff_ign, email } = req.body;

    if (!username || !password)
      return res.status(400).json({ success: false, message: 'Username and password are required.' });
    if (username.trim().length < 3)
      return res.status(400).json({ success: false, message: 'Username must be at least 3 characters.' });
    if (password.length < 6)
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });

    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username.trim().toLowerCase());
    if (existing)
      return res.status(400).json({ success: false, message: 'Username already taken. Choose another.' });

    if (email) {
      const emailTaken = db.prepare('SELECT id FROM users WHERE email = ?').get(email.trim().toLowerCase());
      if (emailTaken)
        return res.status(400).json({ success: false, message: 'Email already registered.' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const result = db.prepare(
      `INSERT INTO users (username, email, password_hash, whatsapp, ff_uid, ff_ign)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      username.trim().toLowerCase(),
      email ? email.trim().toLowerCase() : null,
      password_hash,
      whatsapp ? whatsapp.trim() : '',
      ff_uid   ? ff_uid.trim()   : '',
      ff_ign   ? ff_ign.trim()   : ''
    );

    const token = jwt.sign(
      { id: result.lastInsertRowid, username: username.trim().toLowerCase(), role: 'player' },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    console.log(`👤  NEW USER  →  ${username}`);
    res.status(201).json({
      success  : true,
      message  : 'Account created! Welcome to The Wild Tournament.',
      token,
      user     : {
        id       : result.lastInsertRowid,
        username : username.trim().toLowerCase(),
        ff_uid   : ff_uid || '',
        ff_ign   : ff_ign || '',
        whatsapp : whatsapp || '',
      }
    });
  } catch (e) {
    console.error('Register error:', e.message);
    res.status(500).json({ success: false, message: 'Server error. Try again.' });
  }
});

// POST /api/auth/login — player login
app.post('/api/auth/login', authLimit, async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ success: false, message: 'Username and password required.' });

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username.trim().toLowerCase());
    if (!user)
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid)
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });

    // Update last login
    db.prepare(`UPDATE users SET last_login = datetime('now','localtime') WHERE id = ?`).run(user.id);

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    console.log(`🔑  LOGIN  →  ${user.username}`);
    res.json({
      success : true,
      message : 'Welcome back!',
      token,
      user    : {
        id       : user.id,
        username : user.username,
        ff_uid   : user.ff_uid,
        ff_ign   : user.ff_ign,
        whatsapp : user.whatsapp,
        role     : user.role,
      }
    });
  } catch (e) {
    res.status(500).json({ success: false, message: 'Server error. Try again.' });
  }
});

// GET /api/auth/me — get current user profile
app.get('/api/auth/me', requirePlayerAuth, (req, res) => {
  try {
    const user = db.prepare('SELECT id,username,email,whatsapp,ff_uid,ff_ign,role,created_at,last_login FROM users WHERE id = ?').get(req.user.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    // Get their registration history
    const registrations = db.prepare(
      `SELECT ref_code, lobby_name, entry_fee, payment_status, kills, placement,
              total_earnings, result_status, match_date, created_at
       FROM registrations WHERE user_id = ?
       ORDER BY created_at DESC LIMIT 50`
    ).all(req.user.id);

    // Get their leaderboard entry
    const lbEntry = db.prepare('SELECT * FROM leaderboard WHERE uid = ?').get(user.ff_uid);

    res.json({ success: true, user, registrations, stats: lbEntry || null });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// PATCH /api/auth/profile — update profile
app.patch('/api/auth/profile', requirePlayerAuth, async (req, res) => {
  try {
    const { whatsapp, ff_uid, ff_ign, current_password, new_password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    const fields = [], vals = [];

    if (whatsapp !== undefined) { fields.push('whatsapp = ?'); vals.push(whatsapp.trim()); }
    if (ff_uid   !== undefined) { fields.push('ff_uid = ?');   vals.push(ff_uid.trim());   }
    if (ff_ign   !== undefined) { fields.push('ff_ign = ?');   vals.push(ff_ign.trim());   }

    // Password change
    if (new_password) {
      if (!current_password)
        return res.status(400).json({ success: false, message: 'Current password required to change password.' });
      const valid = await bcrypt.compare(current_password, user.password_hash);
      if (!valid)
        return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
      if (new_password.length < 6)
        return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });
      const hash = await bcrypt.hash(new_password, 10);
      fields.push('password_hash = ?');
      vals.push(hash);
    }

    if (fields.length === 0)
      return res.json({ success: false, message: 'Nothing to update.' });

    vals.push(req.user.id);
    db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...vals);

    res.json({ success: true, message: 'Profile updated successfully.' });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// GET /api/auth/my-registrations — player's own registrations (auth required)
app.get('/api/auth/my-registrations', requirePlayerAuth, (req, res) => {
  try {
    const rows = db.prepare(
      `SELECT ref_code, uid, ign, lobby_name, entry_fee, payment_status,
              room_id, room_password, kills, placement, kill_earnings,
              placement_bonus, total_earnings, result_status, match_date, created_at
       FROM registrations WHERE user_id = ?
       ORDER BY created_at DESC LIMIT 100`
    ).all(req.user.id);

    // Only send room details if payment is verified
    const cleaned = rows.map(r => ({
      ...r,
      room_id       : r.payment_status === 'verified' ? r.room_id       : '',
      room_password : r.payment_status === 'verified' ? r.room_password : '',
    }));

    res.json({ success: true, registrations: cleaned });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// ══════════════════════════════════════════════════════════
//  PUBLIC API (unchanged from v3)
// ══════════════════════════════════════════════════════════

// GET /api/config — lobby config + live slot counts
app.get('/api/config', (_req, res) => {
  try {
    const cfg = {};
    db.prepare('SELECT key, value FROM settings').all().forEach(r => cfg[r.key] = r.value);
    // Never expose admin_password to public
    delete cfg.admin_password;

    const slots = {};
    ['bronze','silver','gold','squad'].forEach(l => {
      const max    = parseInt(cfg[`${l}_slots`]) || 48;
      const filled = getSlotsFilled(l);
      slots[l] = { max, filled, available: max - filled };
    });

    res.json({ success: true, config: cfg, slots });
  } catch (e) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/register — register a player (links to user account if logged in)
app.post('/api/register', regLimit, optionalPlayerAuth, (req, res) => {
  try {
    const { uid, ign, whatsapp, lobby_id, payment_upi, squad_members } = req.body;

    if (!uid || !ign || !whatsapp || !lobby_id)
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    if (uid.trim().length < 5)
      return res.status(400).json({ success: false, message: 'UID must be at least 5 characters.' });

    const LOBBIES = {
      bronze : { name: 'Bronze Lobby', feeKey: 'bronze_entry' },
      silver : { name: 'Silver Lobby', feeKey: 'silver_entry' },
      gold   : { name: 'Gold Lobby',   feeKey: 'gold_entry'   },
      squad  : { name: '4v4 Squad',    feeKey: 'squad_entry'  },
    };

    if (!LOBBIES[lobby_id])
      return res.status(400).json({ success: false, message: 'Invalid lobby selected.' });

    const lobbyName = LOBBIES[lobby_id].name;
    const entryFee  = parseInt(getSetting(LOBBIES[lobby_id].feeKey)) || 5;
    const maxSlots  = parseInt(getSetting(`${lobby_id}_slots`)) || 48;
    const filled    = getSlotsFilled(lobby_id);

    if (filled >= maxSlots)
      return res.status(400).json({ success: false, message: `${lobbyName} is FULL! Try another lobby.` });

    const dup = db.prepare(
      `SELECT id FROM registrations
       WHERE uid = ? AND lobby_id = ? AND payment_status != 'rejected'
       AND date(created_at, 'localtime') = date('now', 'localtime')`
    ).get(uid.trim(), lobby_id);

    if (dup)
      return res.status(400).json({ success: false, message: 'This Free Fire UID is already registered in this lobby today.' });

    const ref_code   = genRef();
    const squad_type = lobby_id === 'squad' ? 'squad' : 'solo';
    const squadJson  = Array.isArray(squad_members) ? JSON.stringify(squad_members) : '[]';
    const user_id    = req.user ? req.user.id : null;  // Link to account if logged in

    db.prepare(
      `INSERT INTO registrations
       (user_id, ref_code, uid, ign, whatsapp, lobby_id, lobby_name, entry_fee, squad_type, squad_members, payment_upi)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(user_id, ref_code, uid.trim(), ign.trim(), whatsapp.trim(), lobby_id, lobbyName, entryFee, squad_type, squadJson, payment_upi || '');

    db.prepare(
      `INSERT INTO transactions (ref_code, uid, ign, amount, type, upi_id) VALUES (?, ?, ?, ?, 'registration', ?)`
    ).run(ref_code, uid.trim(), ign.trim(), entryFee, payment_upi || '');

    db.prepare(
      `INSERT INTO leaderboard (uid, ign, whatsapp, total_matches, total_spent, last_match_at)
       VALUES (?, ?, ?, 1, ?, datetime('now','localtime'))
       ON CONFLICT(uid) DO UPDATE SET
         ign           = excluded.ign,
         whatsapp      = excluded.whatsapp,
         total_matches = total_matches + 1,
         total_spent   = total_spent + ?,
         last_match_at = datetime('now','localtime')`
    ).run(uid.trim(), ign.trim(), whatsapp.trim(), entryFee, entryFee);

    console.log(`✅  REG  ${ref_code}  |  ${ign}  |  ${lobbyName}  |  ₹${entryFee}${user_id ? '  |  user_id='+user_id : ''}`);

    res.status(201).json({
      success         : true,
      ref_code,
      message         : `Registered! Pay ₹${entryFee} to UPI: ${getSetting('upi_id')} and send screenshot to WhatsApp ${getSetting('whatsapp')}`,
      entry_fee       : entryFee,
      lobby_name      : lobbyName,
      slots_remaining : maxSlots - filled - 1,
      upi_id          : getSetting('upi_id'),
      whatsapp        : getSetting('whatsapp'),
      linked_account  : !!user_id,
    });
  } catch (e) {
    console.error('Register error:', e.message);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
});

// GET /api/status/:ref — player checks their registration
app.get('/api/status/:ref', (req, res) => {
  try {
    const reg = db.prepare('SELECT * FROM registrations WHERE ref_code = ?').get(req.params.ref.toUpperCase());
    if (!reg) return res.status(404).json({ success: false, message: 'No registration found for that REF code.' });

    const isVerified = reg.payment_status === 'verified';
    res.json({
      success      : true,
      registration : {
        ref_code        : reg.ref_code,
        uid             : reg.uid,
        ign             : reg.ign,
        lobby_name      : reg.lobby_name,
        entry_fee       : reg.entry_fee,
        payment_status  : reg.payment_status,
        room_id         : isVerified ? reg.room_id       : '',
        room_password   : isVerified ? reg.room_password : '',
        kills           : reg.kills,
        placement       : reg.placement,
        kill_earnings   : reg.kill_earnings,
        placement_bonus : reg.placement_bonus,
        total_earnings  : reg.total_earnings,
        result_status   : reg.result_status,
        match_date      : reg.match_date,
      },
    });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// GET /api/leaderboard — public top 50
app.get('/api/leaderboard', (_req, res) => {
  try {
    const rows = db.prepare(
      `SELECT uid, ign, total_matches, total_kills, total_wins, total_earnings
       FROM leaderboard ORDER BY total_earnings DESC, total_kills DESC LIMIT 50`
    ).all();
    res.json({ success: true, leaderboard: rows });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// ══════════════════════════════════════════════════════════
//  ADMIN API (unchanged from v3)
// ══════════════════════════════════════════════════════════

app.get('/api/admin/stats', adminAuth, (_req, res) => {
  try {
    const q = (sql, ...p) => db.prepare(sql).get(...p);
    const totalRegs  = q(`SELECT COUNT(*) c FROM registrations WHERE date(created_at,'localtime')=date('now','localtime')`).c;
    const verified   = q(`SELECT COUNT(*) c FROM registrations WHERE payment_status='verified'  AND date(created_at,'localtime')=date('now','localtime')`).c;
    const pending    = q(`SELECT COUNT(*) c FROM registrations WHERE payment_status='pending'   AND date(created_at,'localtime')=date('now','localtime')`).c;
    const rejected   = q(`SELECT COUNT(*) c FROM registrations WHERE payment_status='rejected'  AND date(created_at,'localtime')=date('now','localtime')`).c;
    const totalRev   = q(`SELECT COALESCE(SUM(entry_fee),0) s FROM registrations WHERE payment_status='verified'`).s;
    const todayRev   = q(`SELECT COALESCE(SUM(entry_fee),0) s FROM registrations WHERE payment_status='verified' AND date(created_at,'localtime')=date('now','localtime')`).s;
    const totalPrize = q(`SELECT COALESCE(SUM(total_earnings),0) s FROM registrations WHERE result_status='completed'`).s;
    const totalUsers = q(`SELECT COUNT(*) c FROM users`).c;
    const byLobby    = db.prepare(
      `SELECT lobby_id, lobby_name, COUNT(*) count, COALESCE(SUM(entry_fee),0) revenue
       FROM registrations WHERE date(created_at,'localtime')=date('now','localtime') GROUP BY lobby_id`
    ).all();

    const slots = {};
    ['bronze','silver','gold','squad'].forEach(l => {
      slots[l] = { max: parseInt(getSetting(`${l}_slots`)), filled: getSlotsFilled(l) };
    });

    res.json({ success: true, stats: { totalRegs, verified, pending, rejected, totalRev, todayRev, totalPrize, totalUsers, byLobby, slots } });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.get('/api/admin/registrations', adminAuth, (req, res) => {
  try {
    const { lobby, status, date, search } = req.query;
    let sql = 'SELECT * FROM registrations WHERE 1=1';
    const params = [];

    if (lobby)  { sql += ' AND lobby_id = ?';        params.push(lobby); }
    if (status) { sql += ' AND payment_status = ?';  params.push(status); }
    if (date)   { sql += ' AND date(created_at) = ?'; params.push(date); }
    if (search) {
      sql += ' AND (ign LIKE ? OR uid LIKE ? OR ref_code LIKE ? OR whatsapp LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }
    sql += ' ORDER BY created_at DESC LIMIT 500';

    const rows = db.prepare(sql).all(...params);
    res.json({ success: true, registrations: rows, total: rows.length });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.patch('/api/admin/registration/:id', adminAuth, (req, res) => {
  try {
    const reg = db.prepare('SELECT * FROM registrations WHERE id = ?').get(req.params.id);
    if (!reg) return res.status(404).json({ success: false, message: 'Registration not found.' });

    const { payment_status, room_id, room_password, kills, placement, result_status } = req.body;
    const fields = [], vals = [];

    if (payment_status !== undefined) {
      fields.push('payment_status = ?'); vals.push(payment_status);
      if (payment_status === 'verified') {
        fields.push('payment_verified_at = ?');
        vals.push(new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }));
        db.prepare(`UPDATE transactions SET status='completed' WHERE ref_code=?`).run(reg.ref_code);
      }
      if (payment_status === 'rejected')
        db.prepare(`UPDATE transactions SET status='failed' WHERE ref_code=?`).run(reg.ref_code);
    }

    if (room_id       !== undefined) { fields.push('room_id = ?');        vals.push(room_id); }
    if (room_password !== undefined) { fields.push('room_password = ?');  vals.push(room_password); }

    if (kills !== undefined && placement !== undefined) {
      const killRate     = parseInt(getSetting(`${reg.lobby_id}_kill`)) || 0;
      const killEarnings = Math.max(0, parseInt(kills)) * killRate;
      let   placBonus    = 0;

      if (reg.lobby_id === 'gold'  && parseInt(placement) === 1) placBonus = parseInt(getSetting('gold_win_bonus'))  || 60;
      if (reg.lobby_id === 'squad' && parseInt(placement) === 1) placBonus = parseInt(getSetting('squad_win_prize')) || 180;

      const totalEarnings = killEarnings + placBonus;
      fields.push('kills=?','placement=?','kill_earnings=?','placement_bonus=?','total_earnings=?');
      vals.push(parseInt(kills), parseInt(placement), killEarnings, placBonus, totalEarnings);

      db.prepare(
        `UPDATE leaderboard SET
           total_kills    = total_kills + ?,
           total_wins     = total_wins + ?,
           total_earnings = total_earnings + ?
         WHERE uid = ?`
      ).run(parseInt(kills), parseInt(placement) === 1 ? 1 : 0, totalEarnings, reg.uid);

      if (totalEarnings > 0)
        db.prepare(
          `INSERT INTO transactions (ref_code, uid, ign, amount, type, status, notes) VALUES (?,?,?,?,'prize','completed',?)`
        ).run(reg.ref_code, reg.uid, reg.ign, totalEarnings, `Kills:${kills} Placement:#${placement}`);
    }

    if (result_status !== undefined) { fields.push('result_status = ?'); vals.push(result_status); }
    if (fields.length === 0) return res.json({ success: false, message: 'Nothing to update.' });

    fields.push("updated_at = datetime('now','localtime')");
    vals.push(req.params.id);
    db.prepare(`UPDATE registrations SET ${fields.join(', ')} WHERE id = ?`).run(...vals);

    res.json({ success: true, message: 'Registration updated successfully.' });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.delete('/api/admin/registration/:id', adminAuth, (req, res) => {
  try {
    const reg = db.prepare('SELECT ign FROM registrations WHERE id = ?').get(req.params.id);
    if (!reg) return res.status(404).json({ success: false, message: 'Not found.' });
    db.prepare('DELETE FROM registrations WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: `Deleted registration for ${reg.ign}` });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.post('/api/admin/broadcast-room', adminAuth, (req, res) => {
  try {
    const { lobby_id, room_id, room_password } = req.body;
    if (!lobby_id || !room_id)
      return res.status(400).json({ success: false, message: 'lobby_id and room_id are required.' });

    const result = db.prepare(
      `UPDATE registrations SET
         room_id = ?, room_password = ?,
         room_sent_at = datetime('now','localtime')
       WHERE lobby_id = ? AND payment_status = 'verified'
       AND date(created_at,'localtime') = date('now','localtime')`
    ).run(room_id, room_password || '', lobby_id);

    res.json({ success: true, message: `Room details sent to ${result.changes} verified player(s).`, players_updated: result.changes });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.get('/api/admin/transactions', adminAuth, (_req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM transactions ORDER BY created_at DESC LIMIT 300').all();
    res.json({ success: true, transactions: rows });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.get('/api/admin/export', adminAuth, (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().split('T')[0];
    const rows = db.prepare(`SELECT * FROM registrations WHERE date(created_at) = ? ORDER BY lobby_id, created_at`).all(date);
    const cols = ['ref_code','uid','ign','whatsapp','lobby_name','entry_fee','payment_status','room_id','kills','placement','total_earnings','result_status','created_at'];
    const csv  = [
      cols.join(','),
      ...rows.map(r => cols.map(c => `"${String(r[c] || '').replace(/"/g, '""')}"`).join(',')),
    ].join('\n');
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="wild-tournament-${date}.csv"`);
    res.send(csv);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.patch('/api/admin/settings', adminAuth, (req, res) => {
  try {
    const ALLOWED = Object.keys(DEFAULTS);
    const stmt = db.prepare(`INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now','localtime'))`);
    db.transaction(() => {
      for (const [k, v] of Object.entries(req.body))
        if (ALLOWED.includes(k)) stmt.run(k, String(v));
    })();
    res.json({ success: true, message: 'Settings saved successfully.' });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.get('/api/admin/leaderboard', adminAuth, (_req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM leaderboard ORDER BY total_earnings DESC, total_kills DESC').all();
    res.json({ success: true, leaderboard: rows });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// GET /api/admin/users — list all registered user accounts
app.get('/api/admin/users', adminAuth, (req, res) => {
  try {
    const { search } = req.query;
    let sql = `SELECT id, username, email, whatsapp, ff_uid, ff_ign, role, created_at, last_login FROM users`;
    const params = [];
    if (search) {
      sql += ` WHERE username LIKE ? OR email LIKE ? OR ff_ign LIKE ? OR whatsapp LIKE ?`;
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }
    sql += ' ORDER BY created_at DESC LIMIT 200';
    const rows = db.prepare(sql).all(...params);
    res.json({ success: true, users: rows, total: rows.length });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// ── STATIC ROUTES ───────────────────────────────────────────
app.get('/admin',      (_req, res) => res.sendFile(path.join(__dirname, '../public/admin.html')));
app.get('/admin.html', (_req, res) => res.sendFile(path.join(__dirname, '../public/admin.html')));
app.get('/login',      (_req, res) => res.sendFile(path.join(__dirname, '../public/login.html')));
app.get('/dashboard',  (_req, res) => res.sendFile(path.join(__dirname, '../public/dashboard.html')));
app.get('*',           (_req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));

// ── START SERVER ────────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║    🔥  THE WILD TOURNAMENT — SERVER UP  🔥   ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║  🌐  Site      :  http://localhost:${PORT}        ║`);
  console.log(`║  👨‍💼  Admin     :  http://localhost:${PORT}/admin  ║`);
  console.log(`║  🔐  Login     :  http://localhost:${PORT}/login  ║`);
  console.log(`║  📊  Dashboard :  http://localhost:${PORT}/dash.. ║`);
  console.log(`║  🏓  Ping      :  http://localhost:${PORT}/ping   ║`);
  console.log('╚══════════════════════════════════════════════╝');
  console.log('');
});

process.on('SIGINT',  () => { db.close(); console.log('\n👋  Server stopped, DB closed.'); process.exit(0); });
process.on('SIGTERM', () => { db.close(); console.log('\n👋  Server stopped, DB closed.'); process.exit(0); });
